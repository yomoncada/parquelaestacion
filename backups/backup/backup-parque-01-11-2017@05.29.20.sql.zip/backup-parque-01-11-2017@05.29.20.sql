-- # A Mysql Backup System
-- # Export created: 2017/11/01 on 05:29
-- # Database : parque
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `actividades`
DROP TABLE  IF EXISTS `actividades`;
CREATE TABLE `actividades` (
  `id_act` int(4) NOT NULL AUTO_INCREMENT,
  `accion` varchar(300) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo` enum('Censo','Mantenimiento','Reforestación','') COLLATE utf8_spanish2_ci NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id_act`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `actividades` (`id_act`, `accion`, `tipo`, `estado`) VALUES (1, 'Limpiar bancos del pasillo principal', 'Mantenimiento', 'Activa'), 
(2, 'Colocar bombillos en los postes del pasillo principal', 'Mantenimiento', 'Activa'), 
(3, 'Visitar el habitat natural de la especie', 'Censo', 'Activa'), 
(4, 'Explorar el perimetro donde se ubica el habitat de la especie', 'Censo', 'Activa'), 
(5, 'Tacata', 'Reforestación', 'Activa');

-- # Tabel structure for table `actividades_censo`
DROP TABLE  IF EXISTS `actividades_censo`;
CREATE TABLE `actividades_censo` (
  `censo` int(4) NOT NULL,
  `actividad` int(4) NOT NULL,
  `encargado` varchar(80) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `censo` (`censo`,`actividad`,`encargado`),
  KEY `censo_2` (`censo`,`actividad`,`encargado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- # Tabel structure for table `actividades_mantenimiento`
DROP TABLE  IF EXISTS `actividades_mantenimiento`;
CREATE TABLE `actividades_mantenimiento` (
  `mantenimiento` int(4) NOT NULL,
  `actividad` int(4) NOT NULL,
  `encargado` varchar(80) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `censo` (`mantenimiento`,`actividad`,`encargado`),
  KEY `censo_2` (`mantenimiento`,`actividad`,`encargado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- # Tabel structure for table `actividades_reforestacion`
DROP TABLE  IF EXISTS `actividades_reforestacion`;
CREATE TABLE `actividades_reforestacion` (
  `reforestacion` int(4) NOT NULL,
  `actividad` int(4) NOT NULL,
  `encargado` varchar(80) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `censo` (`reforestacion`,`actividad`,`encargado`),
  KEY `censo_2` (`reforestacion`,`actividad`,`encargado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- # Tabel structure for table `areas`
DROP TABLE  IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id_are` int(4) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `area` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_are`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `areas` (`id_are`, `codigo`, `area`, `estado`) VALUES (1, 'P3ST', 'Perimetro Este', 'Activa'), 
(2, 'P0ST', 'Perimetro Oeste', 'Activa'), 
(3, 'P3SV', 'Perimetro Sur', 'Activa'), 
(4, 'P3N0', 'Perimetro Norte', 'Activa');

-- # Tabel structure for table `areas_censo`
DROP TABLE  IF EXISTS `areas_censo`;
CREATE TABLE `areas_censo` (
  `censo` int(4) NOT NULL,
  `id_are` int(4) NOT NULL,
  KEY `mantenimiento` (`censo`,`id_are`),
  KEY `area` (`id_are`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `areas_mantenimiento`
DROP TABLE  IF EXISTS `areas_mantenimiento`;
CREATE TABLE `areas_mantenimiento` (
  `mantenimiento` int(4) NOT NULL,
  `id_are` int(4) NOT NULL,
  KEY `mantenimiento` (`mantenimiento`,`id_are`),
  KEY `area` (`id_are`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `areas_reforestacion`
DROP TABLE  IF EXISTS `areas_reforestacion`;
CREATE TABLE `areas_reforestacion` (
  `reforestacion` int(4) NOT NULL,
  `id_are` int(4) NOT NULL,
  KEY `mantenimiento` (`reforestacion`,`id_are`),
  KEY `area` (`id_are`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `beneficiarios`
DROP TABLE  IF EXISTS `beneficiarios`;
CREATE TABLE `beneficiarios` (
  `id_ben` int(4) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(10) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `telefono` varchar(30) NOT NULL,
  `direccion` varchar(80) NOT NULL,
  `estado` enum('Activo','Inactivo') NOT NULL,
  PRIMARY KEY (`id_ben`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `beneficiarios` (`id_ben`, `cedula`, `nombre`, `telefono`, `direccion`, `estado`) VALUES (1, 'V-27402258', 'Yonathan Moncada', '(0424) 359-1604', 'La Victoria, Estado Aragua', 'Activo'), 
(2, 'V-27402257', 'Petronila Sinforosa', '(0424) 344-1233', 'La Victoria, Estado Aragua', 'Activo'), 
(3, 'V-8589947', 'Esmeralda Navarro', '(0412) 463-3621', 'La Victoria, Estado Aragua', 'Activo'), 
(4, 'V-8071662', 'Luciano Moncada', '(0416) 239-0187', 'La Victoria, Estado Aragua', 'Activo');

-- # Tabel structure for table `beneficiarios_servicio`
DROP TABLE  IF EXISTS `beneficiarios_servicio`;
CREATE TABLE `beneficiarios_servicio` (
  `servicio` int(4) NOT NULL,
  `beneficiario` int(4) NOT NULL,
  KEY `mantenimiento` (`servicio`,`beneficiario`),
  KEY `area` (`beneficiario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `bitacoras`
DROP TABLE  IF EXISTS `bitacoras`;
CREATE TABLE `bitacoras` (
  `id_bit` int(4) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(30) NOT NULL,
  `movimiento` varchar(300) NOT NULL,
  `usuario` int(4) NOT NULL,
  `tiempo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bit`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;

INSERT INTO `bitacoras` (`id_bit`, `tipo`, `movimiento`, `usuario`, `tiempo`) VALUES (1, 'Usuario', 'Ha actualizado su información personal', 1, '2017-10-24 12:32:43'), 
(2, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-24 12:51:33'), 
(3, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-27 18:26:20'), 
(4, 'Usuario', 'Se ha actualizado al usuario <a href=\"http://localhost/parque/index.php/perfil/view/yomoncada\">yomoncada</a>', 1, '2017-10-27 18:26:31'), 
(5, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-27 18:26:35'), 
(6, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-27 18:26:38'), 
(7, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 14:42:34'), 
(8, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 14:42:42'), 
(9, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 14:43:42'), 
(10, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:06:46'), 
(11, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:06:48'), 
(12, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:07:03'), 
(13, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:07:04'), 
(14, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:07:07'), 
(15, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:07:18'), 
(16, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:27:52'), 
(17, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:30:05'), 
(18, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:33:20'), 
(19, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:33:25'), 
(20, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:33:43'), 
(21, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:33:54'), 
(22, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:45:20'), 
(23, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:45:24'), 
(24, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:46:14'), 
(25, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:46:16'), 
(26, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:47:04'), 
(27, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:47:08'), 
(28, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:47:53'), 
(29, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:48:52'), 
(30, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 15:59:49'), 
(31, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 15:59:57'), 
(32, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 16:51:46'), 
(33, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 16:53:02'), 
(34, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:09:50'), 
(35, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:09:56'), 
(36, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:14:42'), 
(37, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:14:46'), 
(38, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:14:50'), 
(39, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:14:52'), 
(40, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:15:04'), 
(41, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:15:06'), 
(42, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:15:23'), 
(43, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:15:25'), 
(44, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:16:38'), 
(45, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:16:40'), 
(46, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:16:44'), 
(47, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:16:46'), 
(48, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:23:10'), 
(49, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:23:13'), 
(50, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:40:43'), 
(51, 'Usuario', 'Se ha actualizado al usuario <a href=\"http://localhost/parque/index.php/perfil/view/luchohnz\">luchohnz</a>', 1, '2017-10-29 17:40:59'), 
(52, 'Usuario', 'Se ha actualizado al usuario <a href=\"http://localhost/parque/index.php/perfil/view/marcoslzr\">marcoslzr</a>', 1, '2017-10-29 17:41:05'), 
(53, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:41:07'), 
(54, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 17:44:27'), 
(55, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 17:44:30'), 
(56, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-29 18:36:30'), 
(57, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-29 19:04:29'), 
(58, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-30 20:57:27'), 
(59, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-30 20:58:34'), 
(60, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-30 21:07:54'), 
(61, 'mantenimiento', 'Se ha registrado un mantenimiento.', 1, '2017-10-30 22:24:55'), 
(62, 'mantenimiento', 'Se ha registrado un mantenimiento.', 1, '2017-10-30 22:26:21'), 
(63, 'mantenimiento', 'Se ha registrado un mantenimiento.', 1, '2017-10-30 22:29:20'), 
(64, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 01:19:14'), 
(65, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 01:20:38'), 
(66, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 01:32:05'), 
(67, 'donacion', 'Se ha actualizado el estado del donacion 12.', 1, '2017-10-31 01:32:39'), 
(68, 'donacion', 'Se ha actualizado el estado del donacion 11.', 1, '2017-10-31 01:33:13'), 
(69, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 09:19:26'), 
(70, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-31 09:19:31'), 
(71, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 09:22:56'), 
(72, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-31 09:27:14'), 
(73, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 09:29:47'), 
(74, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 09:30:51'), 
(75, 'donacion', 'Se ha actualizado el estado del donacion 13.', 1, '2017-10-31 09:31:21'), 
(76, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-31 09:37:33'), 
(77, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 09:37:40'), 
(78, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 09:39:14'), 
(79, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 09:42:46'), 
(80, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 09:51:09'), 
(81, 'donacion', 'Se ha actualizado el estado del donacion 14.', 1, '2017-10-31 09:53:26'), 
(82, 'Actividad', 'Se ha registrado la actividad Tacata.', 1, '2017-10-31 10:22:49'), 
(83, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 16:26:04'), 
(84, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-31 16:26:23'), 
(85, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 16:29:57'), 
(86, 'reforestacion', 'Se ha registrado un reforestacion.', 1, '2017-10-31 16:34:11'), 
(87, 'reforestacion', 'Se ha actualizado el estado del reforestacion 14.', 1, '2017-10-31 16:34:42'), 
(88, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 16:55:48'), 
(89, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 17:01:21'), 
(90, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 17:02:44'), 
(91, 'Censo', 'Se ha registrado un censo.', 1, '2017-10-31 17:32:42'), 
(92, 'Censo', 'Se ha registrado un censo.', 1, '2017-10-31 17:42:41'), 
(93, 'Censo', 'Se ha actualizado el estado del censo 1.', 1, '2017-10-31 17:45:55'), 
(94, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 17:48:31'), 
(95, 'donacion', 'Se ha registrado un donacion.', 1, '2017-10-31 17:58:12'), 
(96, 'donacion', 'Se ha actualizado el estado del donacion 2.', 1, '2017-10-31 18:02:25'), 
(97, 'mantenimiento', 'Se ha registrado un mantenimiento.', 1, '2017-10-31 18:22:24'), 
(98, 'mantenimiento', 'Se ha registrado un mantenimiento.', 1, '2017-10-31 18:23:42'), 
(99, 'mantenimiento', 'Se ha actualizado el estado del mantenimiento 2.', 1, '2017-10-31 18:34:33'), 
(100, 'reforestacion', 'Se ha registrado un reforestacion.', 1, '2017-10-31 18:41:34'), 
(101, 'reforestacion', 'Se ha registrado un reforestacion.', 1, '2017-10-31 18:44:07'), 
(102, 'reforestacion', 'Se ha actualizado el estado del reforestacion 2.', 1, '2017-10-31 18:50:38'), 
(103, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 20:29:18'), 
(104, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 20:29:37'), 
(105, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 20:29:44'), 
(106, 'Beneficiario', 'Se ha actualizado al beneficiario Yonathan Moncada.', 1, '2017-10-31 21:01:36'), 
(107, 'Cabaña', 'Se ha actualizado la cabaña número 1.', 1, '2017-10-31 21:15:16'), 
(108, 'Cancha', 'Se ha actualizado la cancha número 2.', 1, '2017-10-31 21:20:01'), 
(109, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 21:54:17'), 
(110, 'Usuario', 'Ha actualizado su información personal.', 1, '2017-10-31 21:54:58'), 
(111, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 22:35:14'), 
(112, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 22:52:06'), 
(113, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 22:56:09'), 
(114, 'Empleado', 'Se ha actualizado al empleado Esmeralda Navarro.', 1, '2017-10-31 22:56:19'), 
(115, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 22:57:40'), 
(116, 'Usuario', 'Ha salido del sistema.', 1, '2017-10-31 23:04:45'), 
(117, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 23:05:57'), 
(118, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-10-31 23:08:16'), 
(119, 'servicio', 'Se ha registrado un servicio.', 1, '2017-10-31 23:28:41'), 
(120, 'servicio', 'Se ha registrado un servicio.', 1, '2017-10-31 23:30:38'), 
(121, 'servicio', 'Se ha registrado un servicio.', 1, '2017-10-31 23:36:00'), 
(122, 'servicio', 'Se ha actualizado el estado del servicio 13.', 1, '2017-10-31 23:58:11'), 
(123, 'donacion', 'Se ha actualizado el estado del donacion 1.', 1, '2017-11-01 00:05:12'), 
(124, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-11-01 12:22:25'), 
(125, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-11-01 14:58:31'), 
(126, 'Usuario', 'Ha ingresado al sistema.', 1, '2017-11-01 17:06:56');

-- # Tabel structure for table `cabanas`
DROP TABLE  IF EXISTS `cabanas`;
CREATE TABLE `cabanas` (
  `id_cab` int(4) NOT NULL AUTO_INCREMENT,
  `numero` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `area` int(4) NOT NULL,
  `capacidad` int(4) NOT NULL,
  `disponibilidad` enum('Desocupada','Ocupada') COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cab`),
  KEY `area` (`area`),
  CONSTRAINT `cabanas_ibfk_1` FOREIGN KEY (`area`) REFERENCES `areas` (`id_are`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cabanas` (`id_cab`, `numero`, `area`, `capacidad`, `disponibilidad`, `estado`) VALUES (1, 1, 1, 42, 'Ocupada', 'Activa'), 
(2, 2, 2, 12, 'Desocupada', 'Activa'), 
(3, 3, 1, 15, 'Desocupada', 'Activa'), 
(4, 4, 1, 25, 'Desocupada', 'Activa'), 
(5, 5, 2, 12, 'Desocupada', 'Activa'), 
(6, 6, 3, 21, 'Desocupada', 'Activa'), 
(7, 7, 3, 50, 'Desocupada', 'Activa'), 
(8, 9, 4, 25, 'Desocupada', 'Activa'), 
(9, 10, 1, 25, 'Desocupada', 'Activa'), 
(10, 8, 1, 55, 'Desocupada', 'Activa');

-- # Tabel structure for table `cabanas_servicio`
DROP TABLE  IF EXISTS `cabanas_servicio`;
CREATE TABLE `cabanas_servicio` (
  `servicio` int(4) NOT NULL,
  `cabana` int(4) NOT NULL,
  KEY `mantenimiento` (`servicio`,`cabana`),
  KEY `area` (`cabana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `canchas`
DROP TABLE  IF EXISTS `canchas`;
CREATE TABLE `canchas` (
  `id_can` int(4) NOT NULL AUTO_INCREMENT,
  `numero` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `area` int(4) NOT NULL,
  `capacidad` int(4) NOT NULL,
  `disponibilidad` enum('Desocupada','Ocupada') COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_can`),
  KEY `area` (`area`),
  CONSTRAINT `canchas_ibfk_1` FOREIGN KEY (`area`) REFERENCES `areas` (`id_are`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `canchas` (`id_can`, `numero`, `nombre`, `area`, `capacidad`, `disponibilidad`, `estado`) VALUES (1, 1, 'Cancha de Fútbol', 1, 25, 'Ocupada', 'Activa'), 
(2, 2, 'Cancha de Volleyball', 2, 25, 'Desocupada', 'Activa'), 
(3, 3, 'Cancha de Tennis', 2, 24, 'Desocupada', 'Activa'), 
(4, 4, 'Cancha de Basketball', 1, 15, 'Desocupada', 'Activa');

-- # Tabel structure for table `canchas_servicio`
DROP TABLE  IF EXISTS `canchas_servicio`;
CREATE TABLE `canchas_servicio` (
  `servicio` int(4) NOT NULL,
  `cancha` int(4) NOT NULL,
  KEY `mantenimiento` (`servicio`,`cancha`),
  KEY `area` (`cancha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `categorias`
DROP TABLE  IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_cat` int(4) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorias` (`id_cat`, `categoria`, `descripcion`, `estado`) VALUES (1, 'Mantenimiento', 'Implementos para garantizar la seguridad del personal obrero', 'Activa'), 
(2, 'Decoración', 'Implementos de decoración para fiestas, actividades y eventos', 'Activa'), 
(3, 'Seguridad', 'Beticas pa\' seguridad', 'Activa');

-- # Tabel structure for table `censos`
DROP TABLE  IF EXISTS `censos`;
CREATE TABLE `censos` (
  `id_cen` int(4) NOT NULL AUTO_INCREMENT,
  `fecha_act` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario` int(4) NOT NULL,
  `fecha_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `hora_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Pendiente','En progreso','Por revisar','Finalizado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cen`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `ci_sessions`
DROP TABLE  IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ii3jmv1beuq10iel6c5ocgfadiebneu', '::1', 1509509116, '__ci_last_regenerate|i:1509508853;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";especies_contents|a:3:{s:10:\"cart_total\";i:0;s:14:\"total_especies\";i:1;s:32:\"d3d9446802a44259755d38e6d163e820\";a:5:{s:2:\"id\";s:2:\"10\";s:6:\"codigo\";s:4:\"AB03\";s:6:\"nombre\";s:5:\"Uvero\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"d3d9446802a44259755d38e6d163e820\";}}empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"c81e728d9d4c2f636f067f89cc14862c\";a:5:{s:2:\"id\";s:1:\"2\";s:6:\"cedula\";s:10:\"V-27402253\";s:6:\"nombre\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c81e728d9d4c2f636f067f89cc14862c\";}}areas_contents|a:3:{s:10:\"cart_total\";i:0;s:11:\"total_areas\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"codigo\";s:4:\"P3N0\";s:6:\"nombre\";s:15:\"Perimetro Norte\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}edificios_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_edificios\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:6:\"nombre\";s:6:\"Cazona\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}actividades_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_actividades\";i:1;s:32:\"c81e728d9d4c2f636f067f89cc14862c\";a:5:{s:2:\"id\";s:1:\"2\";s:6:\"accion\";s:53:\"Colocar bombillos en los postes del pasillo principal\";s:9:\"encargado\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c81e728d9d4c2f636f067f89cc14862c\";}}proceso|s:16:\"donacion_control\";numero|s:1:\"1\";donantes_contents|a:4:{s:10:\"cart_total\";i:0;s:14:\"total_donantes\";i:2;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:3:\"rif\";s:12:\"J-27402258-8\";s:12:\"razon_social\";s:16:\"Trend Effect C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:3:\"rif\";s:12:\"J-27402253-4\";s:12:\"razon_social\";s:9:\"Skype C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:6:{s:2:\"id\";s:1:\"1\";s:6:\"codigo\";s:4:\"CC20\";s:6:\"nombre\";s:4:\"Pala\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}fondos_contents|a:3:{s:10:\"cart_total\";i:0;s:12:\"total_fondos\";d:1000;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:4:{s:2:\"id\";i:1;s:6:\"divisa\";s:1:\"0\";s:8:\"cantidad\";d:1000;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}'), 
('154k9niucs0ttmr1pek93oas81th09rd', '::1', 1509570390, '__ci_last_regenerate|i:1509570344;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('16vpoqoeh4rea3b5b61podl1c4a7acg8', '::1', 1509505863, '__ci_last_regenerate|i:1509505691;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"servicio\";empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:10:\"V-27402264\";s:6:\"nombre\";s:15:\"Luciano Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}invitados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_invitados\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";i:1;s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:6:{s:2:\"id\";s:1:\"1\";s:6:\"codigo\";s:4:\"CC20\";s:6:\"nombre\";s:4:\"Pala\";s:6:\"unidad\";s:8:\"Unidades\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}'), 
('1971md8p52n211pit5lh7vci42mre07f', '::1', 1509571319, '__ci_last_regenerate|i:1509571059;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('21d7sv4buucsiueasecq25hvbf5ret1c', '::1', 1509565385, '__ci_last_regenerate|i:1509565275;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:5:\"censo\";'), 
('2hvaklj110jur9i6mbgu0fhf27n5i7pq', '::1', 1509573537, '__ci_last_regenerate|i:1509573440;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('3ima9i1fu9385vkbjmt4h0a9916mcscv', '::1', 1509570647, '__ci_last_regenerate|i:1509570410;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('4hu1sa4fl5e79p6jq8gnrkb8g6j73hpo', '::1', 1509569919, '__ci_last_regenerate|i:1509569699;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('4oam7o3rp6i8857q1n4rbqejaa5j6gui', '::1', 1509505562, '__ci_last_regenerate|i:1509505485;token|s:40:\"d8b1752ecd406e25c6f5e93697f510b7c9895f9b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"servicio\";'), 
('4r1rdnpv1553tt0821h1b28l6u9o37co', '::1', 1509573073, '__ci_last_regenerate|i:1509572786;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:5:\"censo\";'), 
('7dlatli6bf4skvi806g3gnpr7lg4dk7k', '::1', 1509569258, '__ci_last_regenerate|i:1509569040;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('8c2jtgi75l11eq3q64nt9tp0kv21tjqa', '::1', 1509507544, '__ci_last_regenerate|i:1509507272;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"servicio_control\";beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:9:\"V-8589947\";s:6:\"nombre\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"cedula\";s:10:\"V-24388345\";s:6:\"nombre\";s:17:\"Dubrazka Landaeta\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:6:{s:2:\"id\";s:1:\"4\";s:6:\"codigo\";s:4:\"CC21\";s:6:\"nombre\";s:8:\"Martillo\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('90kou9lq8hp3pa6ksr1ra9vamtcq45bn', '::1', 1509571422, '__ci_last_regenerate|i:1509571422;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('9a8s9qigp5eu70b28qte00abkf7o7q04', '::1', 1509568003, '__ci_last_regenerate|i:1509567809;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('9io924d52tqv13dv0ktuo9dibhrdht5d', '::1', 1509570275, '__ci_last_regenerate|i:1509570016;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('a8ikbt1d8446u4h3lgehuivvt710cj7a', '::1', 1509568612, '__ci_last_regenerate|i:1509568325;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('adjmhbm4jsaagv2nkplf67mhiocpkffj', '::1', 1509573392, '__ci_last_regenerate|i:1509573125;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('c5m0fi9ohqo9a1f902li81j8m890fhn7', '::1', 1509569615, '__ci_last_regenerate|i:1509569363;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('fqo7tf97g79rhl682phikkkrr8rq8hfi', '::1', 1509506435, '__ci_last_regenerate|i:1509506155;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"servicio\";empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:10:\"V-27402264\";s:6:\"nombre\";s:15:\"Luciano Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}invitados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_invitados\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";i:1;s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:6:{s:2:\"id\";s:1:\"1\";s:6:\"codigo\";s:4:\"CC20\";s:6:\"nombre\";s:4:\"Pala\";s:6:\"unidad\";s:8:\"Unidades\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}'), 
('g1iunhrdpo6uev0fmo8g7immsggcu1jl', '::1', 1509570976, '__ci_last_regenerate|i:1509570718;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('g4kbr4boi9erp9c44ji70jua6gbhheku', '::1', 1509508797, '__ci_last_regenerate|i:1509508517;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"donacion_control\";numero|s:1:\"2\";donantes_contents|a:3:{s:10:\"cart_total\";i:0;s:14:\"total_donantes\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:3:\"rif\";s:12:\"J-27402253-4\";s:12:\"razon_social\";s:9:\"Skype C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('hhc7kovni1nqlb13gaj4golulig4q4mb', '::1', 1509508378, '__ci_last_regenerate|i:1509508205;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"servicio_control\";beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:9:\"V-8589947\";s:6:\"nombre\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"cedula\";s:10:\"V-24388345\";s:6:\"nombre\";s:17:\"Dubrazka Landaeta\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:6:{s:2:\"id\";s:1:\"4\";s:6:\"codigo\";s:4:\"CC21\";s:6:\"nombre\";s:8:\"Martillo\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('jfa90n8jp0k4696vm9obv177vv64df1s', '::1', 1509509628, '__ci_last_regenerate|i:1509509473;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";donantes_contents|a:4:{s:10:\"cart_total\";i:0;s:14:\"total_donantes\";i:2;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:3:\"rif\";s:12:\"J-27402258-8\";s:12:\"razon_social\";s:16:\"Trend Effect C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:3:\"rif\";s:12:\"J-27402253-4\";s:12:\"razon_social\";s:9:\"Skype C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}fondos_contents|a:3:{s:10:\"cart_total\";i:0;s:12:\"total_fondos\";d:1000;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:4:{s:2:\"id\";i:1;s:6:\"divisa\";s:10:\"Bolívares\";s:8:\"cantidad\";d:1000;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}numero|s:1:\"1\";proceso|s:13:\"mantenimiento\";'), 
('lcr4tp333kt9c8f0cv5dgfmtai8ghfd3', '::1', 1509506889, '__ci_last_regenerate|i:1509506584;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"servicio\";empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:10:\"V-27402264\";s:6:\"nombre\";s:15:\"Luciano Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}invitados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_invitados\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";i:1;s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:6:{s:2:\"id\";s:1:\"1\";s:6:\"codigo\";s:4:\"CC20\";s:6:\"nombre\";s:4:\"Pala\";s:6:\"unidad\";s:8:\"Unidades\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}'), 
('lhveab680clp8jvlg2kf7ofo0m2fn12i', '::1', 1509567981, '__ci_last_regenerate|i:1509567877;token|s:40:\"9496904bb44a59cf7b06ca9242d0a69b32fbd8ad\";'), 
('ln0f2njp98n5l39upt6u7c7b0mvis7vt', '::1', 1509566698, '__ci_last_regenerate|i:1509566438;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('lna4ir9mvqo1jhq8ktnah560s7eqge6i', '::1', 1509562848, '__ci_last_regenerate|i:1509562704;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"donacion\";'), 
('m05jt65h2jreuhcrn14ev6fl4ojviahd', '::1', 1509507078, '__ci_last_regenerate|i:1509506905;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"servicio_control\";'), 
('nvarg6qh76f1j2pebg93c4iv8hbmokm3', '::1', 1509566434, '__ci_last_regenerate|i:1509566127;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('o3o560b1oqgjgd4t15hrs13naeqpshq2', '::1', 1509568947, '__ci_last_regenerate|i:1509568678;token|s:40:\"6c48d50135e4f4c47ad8019a4639ab9bdf913c1d\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('puilv6u0uuho9l4ki95s62vmpf3nv505', '::1', 1509508000, '__ci_last_regenerate|i:1509507893;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"servicio_control\";beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:9:\"V-8589947\";s:6:\"nombre\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"cedula\";s:10:\"V-24388345\";s:6:\"nombre\";s:17:\"Dubrazka Landaeta\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:6:{s:2:\"id\";s:1:\"4\";s:6:\"codigo\";s:4:\"CC21\";s:6:\"nombre\";s:8:\"Martillo\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('rmk6bgiv40dd55k4p7ppbrluulgoosn2', '::1', 1509572056, '__ci_last_regenerate|i:1509571770;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('rmul8lrr27q9tcskbltpadgat4svc4j0', '::1', 1509509458, '__ci_last_regenerate|i:1509509160;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";edificios_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_edificios\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:6:\"nombre\";s:6:\"Cazona\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}donantes_contents|a:4:{s:10:\"cart_total\";i:0;s:14:\"total_donantes\";i:2;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:3:\"rif\";s:12:\"J-27402258-8\";s:12:\"razon_social\";s:16:\"Trend Effect C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:3:\"rif\";s:12:\"J-27402253-4\";s:12:\"razon_social\";s:9:\"Skype C.A\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}fondos_contents|a:3:{s:10:\"cart_total\";i:0;s:12:\"total_fondos\";d:1000;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:4:{s:2:\"id\";i:1;s:6:\"divisa\";s:10:\"Bolívares\";s:8:\"cantidad\";d:1000;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}proceso|s:13:\"censo_control\";numero|s:1:\"1\";empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"cedula\";s:10:\"V-27402258\";s:6:\"nombre\";s:16:\"Yonathan Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}areas_contents|a:3:{s:10:\"cart_total\";i:0;s:11:\"total_areas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"codigo\";s:4:\"P3ST\";s:6:\"nombre\";s:14:\"Perimetro Este\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}especies_contents|a:3:{s:10:\"cart_total\";i:0;s:14:\"total_especies\";i:1;s:32:\"d3d9446802a44259755d38e6d163e820\";a:5:{s:2:\"id\";s:2:\"10\";s:6:\"codigo\";s:4:\"AB03\";s:6:\"nombre\";s:5:\"Uvero\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"d3d9446802a44259755d38e6d163e820\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"e4da3b7fbbce2345d7772b0674a318d5\";a:6:{s:2:\"id\";s:1:\"5\";s:6:\"codigo\";s:4:\"CC22\";s:6:\"nombre\";s:5:\"Botas\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"e4da3b7fbbce2345d7772b0674a318d5\";}}actividades_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_actividades\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"accion\";s:61:\"Explorar el perimetro donde se ubica el habitat de la especie\";s:9:\"encargado\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('s22eu3i3nggq4i4uovhi1v5a6758l3kf', '::1', 1509572376, '__ci_last_regenerate|i:1509572081;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('taul4o3o5mkfank54kmkm3cnlbdr29bh', '::1', 1509572669, '__ci_last_regenerate|i:1509572400;token|s:40:\"09f6877cbc82aa61eb44f50fdee63f9de735db55\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";'), 
('u01r178o3pa8q1gr7cjq883j4tiv56i4', '::1', 1509507829, '__ci_last_regenerate|i:1509507586;token|s:40:\"1e0316af2a0ede07359d9f0fbf5d36b49274a21b\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:16:\"servicio_control\";beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";a:5:{s:2:\"id\";s:1:\"3\";s:6:\"cedula\";s:9:\"V-8589947\";s:6:\"nombre\";s:17:\"Esmeralda Navarro\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"eccbc87e4b5ce2fe28308fd9f2a7baf3\";}}cabanas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_cabanas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"42\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}canchas_contents|a:3:{s:10:\"cart_total\";i:0;s:13:\"total_canchas\";i:1;s:32:\"c4ca4238a0b923820dcc509a6f75849b\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"numero\";s:1:\"1\";s:9:\"capacidad\";s:2:\"25\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"c4ca4238a0b923820dcc509a6f75849b\";}}empleados_contents|a:3:{s:10:\"cart_total\";i:0;s:15:\"total_empleados\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"cedula\";s:10:\"V-24388345\";s:6:\"nombre\";s:17:\"Dubrazka Landaeta\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}implementos_contents|a:3:{s:10:\"cart_total\";i:0;s:17:\"total_implementos\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:6:{s:2:\"id\";s:1:\"4\";s:6:\"codigo\";s:4:\"CC21\";s:6:\"nombre\";s:8:\"Martillo\";s:8:\"cantidad\";i:1;s:6:\"unidad\";s:8:\"Unidades\";s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}'), 
('uuj0c5irar7dsh25gu6vgh6obf44ca40', '::1', 1509553427, '__ci_last_regenerate|i:1509553339;token|s:40:\"4e53b071a95b4f4149387136c70bdad2fba29f01\";is_logued_in|b:1;id_usuario|s:1:\"1\";nivel|s:16:\"Administrador(a)\";usuario|s:9:\"yomoncada\";proceso|s:8:\"servicio\";beneficiarios_contents|a:3:{s:10:\"cart_total\";i:0;s:19:\"total_beneficiarios\";i:1;s:32:\"a87ff679a2f3e71d9181a67b7542122c\";a:5:{s:2:\"id\";s:1:\"4\";s:6:\"cedula\";s:9:\"V-8071662\";s:6:\"nombre\";s:15:\"Luciano Moncada\";s:8:\"cantidad\";i:1;s:5:\"rowid\";s:32:\"a87ff679a2f3e71d9181a67b7542122c\";}}');

-- # Tabel structure for table `donaciones`
DROP TABLE  IF EXISTS `donaciones`;
CREATE TABLE `donaciones` (
  `id_dnc` int(4) NOT NULL AUTO_INCREMENT,
  `fecha_act` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario` int(4) NOT NULL,
  `fecha_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `hora_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Pendiente','En progreso','Por revisar','Finalizado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_dnc`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `donantes`
DROP TABLE  IF EXISTS `donantes`;
CREATE TABLE `donantes` (
  `id_don` int(4) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_don`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `donantes` (`id_don`, `rif`, `razon_social`, `telefono`, `direccion`, `estado`) VALUES (1, 'J-27402258-9', 'Connecting People C.A', '(0244) 323-4011', 'La Victoria, Estado Aragua', 'Inactivo'), 
(2, 'J-27402258-7', 'La Mansión de Michelle C.A', '(0244) 322-8569', 'La Victoria, Estado Aragua', 'Activo'), 
(3, 'J-27402258-8', 'Trend Effect C.A', '(0244) 323-4011', 'La Victoria, Estado Aragua', 'Activo'), 
(4, 'J-27402253-4', 'Skype C.A', '(0244) 323-4011', 'La Victoria, Estado Aragua', 'Activo');

-- # Tabel structure for table `donantes_donacion`
DROP TABLE  IF EXISTS `donantes_donacion`;
CREATE TABLE `donantes_donacion` (
  `donacion` int(4) NOT NULL,
  `donante` int(4) NOT NULL,
  KEY `mantenimiento` (`donacion`,`donante`),
  KEY `area` (`donante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `edificios`
DROP TABLE  IF EXISTS `edificios`;
CREATE TABLE `edificios` (
  `id_edi` int(4) NOT NULL AUTO_INCREMENT,
  `numero` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `area` int(4) NOT NULL,
  `descripcion` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_edi`),
  KEY `area` (`area`),
  CONSTRAINT `edificios_ibfk_1` FOREIGN KEY (`area`) REFERENCES `areas` (`id_are`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `edificios` (`id_edi`, `numero`, `nombre`, `area`, `descripcion`, `estado`) VALUES (1, 1, 'Cazona', 3, '', 'Activo'), 
(2, 2, 'Recibo', 2, '', 'Activo'), 
(3, 3, 'Pasarela', 1, 'Tacata', 'Activo');

-- # Tabel structure for table `edificios_mantenimiento`
DROP TABLE  IF EXISTS `edificios_mantenimiento`;
CREATE TABLE `edificios_mantenimiento` (
  `mantenimiento` int(4) NOT NULL,
  `edificio` int(4) NOT NULL,
  KEY `mantenimiento` (`mantenimiento`,`edificio`),
  KEY `area` (`edificio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `empleados`
DROP TABLE  IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id_emp` int(4) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `cargo` enum('Recepcionista','Albañil','Mantenimiento','Seguridad') COLLATE utf8_spanish_ci NOT NULL,
  `turno` enum('Diurno','Nocturno') COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `disponibilidad` enum('Desocupado','Ocupado') COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` (`id_emp`, `cedula`, `nombre`, `cargo`, `turno`, `telefono`, `email`, `direccion`, `disponibilidad`, `estado`) VALUES (1, 'V-27402258', 'Yonathan Moncada', 'Mantenimiento', 'Diurno', '(0424) 359-1604', 'yomoncadabooking@gmail.com', 'La Victoria, Estado Aragua', 'Ocupado', 'Activo'), 
(2, 'V-27402253', 'Esmeralda Navarro', 'Seguridad', 'Diurno', '(0424) 355-2311', '', 'La Victoria, Estado Aragua', 'Ocupado', 'Activo'), 
(3, 'V-27402264', 'Luciano Moncada', 'Recepcionista', 'Diurno', '(0424) 233-4566', '', 'La Victoria, Estado Aragua', 'Ocupado', 'Activo'), 
(4, 'V-24388345', 'Dubrazka Landaeta', 'Mantenimiento', 'Diurno', '(0426) 256-3320', '', 'El Consejo, Estado Aragua', 'Ocupado', 'Activo');

-- # Tabel structure for table `empleados_censo`
DROP TABLE  IF EXISTS `empleados_censo`;
CREATE TABLE `empleados_censo` (
  `censo` int(4) NOT NULL,
  `empleado` int(4) NOT NULL,
  KEY `mantenimiento` (`censo`,`empleado`),
  KEY `area` (`empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `empleados_mantenimiento`
DROP TABLE  IF EXISTS `empleados_mantenimiento`;
CREATE TABLE `empleados_mantenimiento` (
  `mantenimiento` int(4) NOT NULL,
  `empleado` int(4) NOT NULL,
  KEY `mantenimiento` (`mantenimiento`,`empleado`),
  KEY `area` (`empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `empleados_reforestacion`
DROP TABLE  IF EXISTS `empleados_reforestacion`;
CREATE TABLE `empleados_reforestacion` (
  `reforestacion` int(4) NOT NULL,
  `empleado` int(4) NOT NULL,
  KEY `mantenimiento` (`reforestacion`,`empleado`),
  KEY `area` (`empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `empleados_servicio`
DROP TABLE  IF EXISTS `empleados_servicio`;
CREATE TABLE `empleados_servicio` (
  `servicio` int(4) NOT NULL,
  `empleado` int(4) NOT NULL,
  KEY `mantenimiento` (`servicio`,`empleado`),
  KEY `area` (`empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `especies`
DROP TABLE  IF EXISTS `especies`;
CREATE TABLE `especies` (
  `id_esp` int(4) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `nom_cmn` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `nom_cntfc` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `flia` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` enum('Flora','Fauna') COLLATE utf8_spanish_ci NOT NULL,
  `poblacion` int(3) NOT NULL,
  `riesgo` int(3) NOT NULL,
  `extincion` int(3) NOT NULL,
  `estado` enum('Activa','Inactiva') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_esp`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `especies` (`id_esp`, `codigo`, `nom_cmn`, `nom_cntfc`, `flia`, `tipo`, `poblacion`, `riesgo`, `extincion`, `estado`) VALUES (1, 'AA03', 'Apamate', 'Tebebuia Rosea', 'Bignoniaceae', 'Flora', 50, 10, 3, 'Activa'), 
(2, 'AA04', 'Cachicamo', 'Dasypus N. Novencintus', 'Dasipódidos', 'Fauna', 10, 2, 0, 'Activa'), 
(3, 'AA05', 'Ardilla', 'Sciurus Aestuans', 'Sciuridae', 'Fauna', 10, 5, 0, 'Activa'), 
(4, 'AA06', 'Perico', 'Melopsittacus Undulatus', 'Psittacidae', 'Fauna', 25, 5, 0, 'Activa'), 
(5, 'AA07', 'Oso Perezoso', 'Bodypus Variegatus', 'Bradypodidae', 'Fauna', 60, 10, 0, 'Activa'), 
(6, 'AA08', 'Murciélago', 'Pipistrellus', 'Verspertilionidae', 'Fauna', 25, 5, 0, 'Activa'), 
(7, 'AA10', 'Bambú', 'Bambusa Arundinacea', 'Poaceae', 'Flora', 10, 5, 0, 'Activa'), 
(8, 'AB01', 'Guayaba', 'Psidium Guajava', 'Myrtaceae', 'Flora', 50, 10, 0, 'Activa'), 
(9, 'AB02', 'Mango', 'Mangifera Indica', 'Sapindaceae', 'Flora', 25, 5, 0, 'Activa'), 
(10, 'AB03', 'Uvero', 'Coccoloba caracasana', 'Polygonaceae', 'Flora', 25, 5, 0, 'Activa');

-- # Tabel structure for table `especies_censo`
DROP TABLE  IF EXISTS `especies_censo`;
CREATE TABLE `especies_censo` (
  `censo` int(4) NOT NULL,
  `especie` int(4) NOT NULL,
  KEY `mantenimiento` (`censo`,`especie`),
  KEY `empleado` (`especie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `especies_reforestacion`
DROP TABLE  IF EXISTS `especies_reforestacion`;
CREATE TABLE `especies_reforestacion` (
  `reforestacion` int(4) NOT NULL,
  `especie` int(4) NOT NULL,
  KEY `mantenimiento` (`reforestacion`,`especie`),
  KEY `empleado` (`especie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `fondos_donacion`
DROP TABLE  IF EXISTS `fondos_donacion`;
CREATE TABLE `fondos_donacion` (
  `donacion` int(4) NOT NULL,
  `cantidad` int(4) NOT NULL,
  `divisa` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `donacion` (`donacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- # Tabel structure for table `implementos`
DROP TABLE  IF EXISTS `implementos`;
CREATE TABLE `implementos` (
  `id_imp` int(4) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `categoria` int(4) NOT NULL,
  `stock` int(4) NOT NULL,
  `stock_min` int(4) NOT NULL,
  `stock_max` int(4) NOT NULL,
  `unidad` enum('Kilogramos','Gramos','Litros','Mililitros','Unidades') COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_imp`),
  UNIQUE KEY `categoria` (`categoria`),
  UNIQUE KEY `categoria_2` (`categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `implementos` (`id_imp`, `codigo`, `nombre`, `categoria`, `stock`, `stock_min`, `stock_max`, `unidad`, `estado`) VALUES (1, 'CC20', 'Pala', 1, 71, 1, 100, 'Unidades', 'Activo'), 
(4, 'CC21', 'Martillo', 2, 3, 1, 50, 'Unidades', 'Activo'), 
(5, 'CC22', 'Botas', 3, 33, 1, 100, 'Unidades', 'Activo');

-- # Tabel structure for table `implementos_censo`
DROP TABLE  IF EXISTS `implementos_censo`;
CREATE TABLE `implementos_censo` (
  `censo` int(4) NOT NULL,
  `implemento` int(4) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  KEY `mantenimiento` (`censo`,`implemento`),
  KEY `implemento` (`implemento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `implementos_donacion`
DROP TABLE  IF EXISTS `implementos_donacion`;
CREATE TABLE `implementos_donacion` (
  `donacion` int(4) NOT NULL,
  `implemento` int(4) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  KEY `mantenimiento` (`donacion`,`implemento`),
  KEY `implemento` (`implemento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `implementos_mantenimiento`
DROP TABLE  IF EXISTS `implementos_mantenimiento`;
CREATE TABLE `implementos_mantenimiento` (
  `mantenimiento` int(4) NOT NULL,
  `implemento` int(4) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  KEY `mantenimiento` (`mantenimiento`,`implemento`),
  KEY `implemento` (`implemento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `implementos_reforestacion`
DROP TABLE  IF EXISTS `implementos_reforestacion`;
CREATE TABLE `implementos_reforestacion` (
  `reforestacion` int(4) NOT NULL,
  `implemento` int(4) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  KEY `mantenimiento` (`reforestacion`,`implemento`),
  KEY `implemento` (`implemento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `implementos_servicio`
DROP TABLE  IF EXISTS `implementos_servicio`;
CREATE TABLE `implementos_servicio` (
  `servicio` int(4) NOT NULL,
  `implemento` int(4) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  KEY `mantenimiento` (`servicio`,`implemento`),
  KEY `implemento` (`implemento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `invitados_servicio`
DROP TABLE  IF EXISTS `invitados_servicio`;
CREATE TABLE `invitados_servicio` (
  `servicio` int(4) NOT NULL,
  `cedula` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `nombre` varchar(80) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

-- # Tabel structure for table `mantenimientos`
DROP TABLE  IF EXISTS `mantenimientos`;
CREATE TABLE `mantenimientos` (
  `id_man` int(4) NOT NULL AUTO_INCREMENT,
  `fecha_act` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario` int(4) NOT NULL,
  `fecha_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `hora_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Pendiente','En progreso','Por revisar','Finalizado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_man`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `reforestaciones`
DROP TABLE  IF EXISTS `reforestaciones`;
CREATE TABLE `reforestaciones` (
  `id_ref` int(4) NOT NULL AUTO_INCREMENT,
  `fecha_act` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario` int(4) NOT NULL,
  `fecha_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `hora_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Pendiente','En progreso','Por revisar','Finalizado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_ref`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `servicios`
DROP TABLE  IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `id_ser` int(4) NOT NULL AUTO_INCREMENT,
  `fecha_act` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario` int(4) NOT NULL,
  `fecha_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `hora_asig` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Pendiente','En progreso','Por revisar','Finalizado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_ser`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- # Tabel structure for table `usuarios`
DROP TABLE  IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usu` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `biografia` varchar(120) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` enum('H','M') COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `contraseña` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `nivel` enum('Administrador(a)','Secretario(a)') COLLATE utf8_spanish_ci NOT NULL,
  `pregunta` enum('¿Cuál fue el nombre de tu primera mascota?','¿Cuál es la profesión de tu abuelo?','¿Cómo se llama tu mejor amigo de la infancia?','¿Cuál fue tu clase favorita en el colegio?') COLLATE utf8_spanish_ci NOT NULL,
  `respuesta` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `estado` enum('Activo','Inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_usu`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuarios` (`id_usu`, `nombre`, `biografia`, `telefono`, `sexo`, `direccion`, `usuario`, `contraseña`, `nivel`, `pregunta`, `respuesta`, `estado`) VALUES (1, 'Yonathan Moncada', 'Diseñador Gráfico, Productor Audiovisual, Desarollador Web. 
20 años. 
Venezolano', '(0424) 359-1604', 'H', 'La Victoria, Estado Aragua', 'yomoncada', '601f1889667efaebb33b8c12572835da3f027f78', 'Administrador(a)', '¿Cuál fue el nombre de tu primera mascota?', 'Firulais', 'Activo'), 
(2, 'Luís Hernández', '', '(0414) 945-2962', 'H', 'La Victoria, Estado Aragua', 'luchohnz', '1a2bf0adea0f4b41ed9f7a02d31fa535d5743f3e', 'Secretario(a)', '¿Cuál es la profesión de tu abuelo?', 'Agricultor', 'Activo'), 
(3, 'Marco Salazar', '', '(0424) 306-6682', 'H', 'La Victoria, Estado Aragua', 'marcoslzr', 'ccbe91b1f19bd31a1365363870c0eec2296a61c1', 'Administrador(a)', '¿Cuál fue el nombre de tu primera mascota?', 'Doggie', 'Activo'), 
(4, '', '', '', 'H', '', 'alejandrop', '2f52d32a2c3fed7f2117065edc79fc3b5c2a37aa', 'Secretario(a)', '¿Cuál fue el nombre de tu primera mascota?', 'Golden', 'Activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
